#ifndef TOUCHGFX_CONFIG_H
#define TOUCHGFX_CONFIG_H

#define TOUCHGFX_ENABLED        0

/**
 * Waring: Only one PORT define should be enabled at a time!
 */
#define TOUCHGFX_BAREMETAL		1
#define TOUCHGFX_FREERTOS		0

#endif // TOUCHGFX_CONFIG_H
